---
layout: main
title: Domov
---

## Volám sa Miloš Pallo


### Študujem informatiku na [Fakulte informatiky a informačných technológií na STU v Bratislave](http://www.fiit.stuba.sk/).

#### Toto je moja osobnostná stránka na GitHub Pages.


