---
layout: post
title: "Dva roky na FIIT"
date: 2016-03-06
category: blog
---

Hovorí sa, že štúdium na FIIT STU v Bratislave je náročné. Toto tvrdenie môžem potvrdiť, ale zároveň musím konštatovať,
že ani som si neuvedomil a už som v 6. semestri. Ako ten čas rýchlo letí. Len nedávno som bol prvák, ktorý s obavami a
očakávaním nastupoval na vysokú školu a už pomaly končí bakalárksy stupeň štúdia. Preto vás povzbudzujem, ak vás to baví,
tak neváhajte investovať svoj čas na štúdium na vysokej škole. Je to krásne a zmysluplne strávené obdobie vášho života.
