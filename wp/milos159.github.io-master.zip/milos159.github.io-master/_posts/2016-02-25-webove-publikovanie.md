---
layout: post
title: "Webové publikovanie"
date: 2016-02-25
category: blog
---

## Začiatok s predmetom webové publikovanie

Prvé zadanie z predmetu webové publikovanie bolo vytvoriť si osobnostnú stránku na GitHub Pages.
Pri tomto zadaní sa využívali technológie _Git + GitHub Pages + Jekyll + Markdown_, pričom bol
kladený dôraz na využívanie statického generátora Jekyll a jeho templatovacích možností s použitím
značkovacieho jazyka Markdown.
